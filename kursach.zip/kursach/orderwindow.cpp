#include "orderwindow.h"
#include "ui_orderwindow.h"

OrderWindow::OrderWindow(int readerId, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::orderwindow),
    readerId(readerId)
{
    ui->setupUi(this);

    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("C:/QT PROJECTS/kursach/mydatabase.db");
    if (!db.open()) {
        QMessageBox::critical(this, "Ошибка", "Ошибка открытия базы данных: " + db.lastError().text());
    }

    QSqlQuery query(db);
    query.prepare("SELECT Название FROM books");
    if (!query.exec()) {
        QMessageBox::critical(this, "Ошибка", "Ошибка выполнения запроса: " + query.lastError().text());
    } else {
        QStringList bookTitles;
        while (query.next()) {
            bookTitles << query.value(0).toString();
        }

        completer = new QCompleter(bookTitles, this);
        completer->setCaseSensitivity(Qt::CaseInsensitive);
        ui->booksLineEdit->setCompleter(completer);
    }
}

OrderWindow::~OrderWindow()
{
    delete ui;
    delete completer;
}

void OrderWindow::on_makeOrderButton_clicked()
{
     QString bookTitle = ui->booksLineEdit->text();
    QString userName = ui->userNameLineEdit->text();
    QString userEmail = ui->userEmailLineEdit->text();

    QSqlQuery query(db);
    query.prepare("SELECT ID_читателя FROM readers WHERE Имя = :name");
    query.bindValue(":name", userName);
    if (!query.exec()) {
        QMessageBox::critical(this, "Ошибка", "Ошибка выполнения запроса: " + query.lastError().text());
        return;
    }

    int readerId;
    if (query.next()) {
        readerId = query.value(0).toInt();
    } else {
        query.prepare("INSERT INTO readers (Имя, Контактная_информация) VALUES (:name, :email)");
        query.bindValue(":name", userName);
        query.bindValue(":email", userEmail);
        if (!query.exec()) {
            QMessageBox::critical(this, "Ошибка", "Ошибка выполнения запроса: " + query.lastError().text());
            return;
        }

        readerId = query.lastInsertId().toInt();
    }

    query.prepare("SELECT ID_книги FROM books WHERE Название = :title");
    query.bindValue(":title", bookTitle);
    if (!query.exec()) {
        QMessageBox::critical(this, "Ошибка", "Ошибка выполнения запроса: " + query.lastError().text());
        return;
    }

    if (!query.next()) {
        QMessageBox::warning(this, "Ошибка", "Книга не найдена");
        return;
    }

    int bookId = query.value(0).toInt();
    QString currentDate = QDateTime::currentDateTime().toString("yyyy-MM-dd");

    query.prepare("INSERT INTO book_issuance (ID_читателя, ID_книги, Дата_выдачи) VALUES (:readerId, :bookId, :date)");
    query.bindValue(":readerId", readerId);
    query.bindValue(":bookId", bookId);
    query.bindValue(":date", currentDate);
    if (!query.exec()) {
        QMessageBox::critical(this, "Ошибка", "Ошибка выполнения запроса: " + query.lastError().text());
    } else {
        QMessageBox::information(this, "Успех", "Заказ успешно создан");
        accept();
    }
}
