// orderwindow.h
#ifndef ORDERWINDOW_H
#define ORDERWINDOW_H

#include <QDialog>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QDateTime>
#include <QCompleter>

namespace Ui {
class orderwindow;
}

class OrderWindow : public QDialog
{
    Q_OBJECT

public:
    explicit OrderWindow(int readerId, QWidget *parent = nullptr);
    ~OrderWindow();

private slots:
    void on_makeOrderButton_clicked();

private:
    Ui::orderwindow *ui;
    QSqlDatabase db;
    int readerId;
    QCompleter *completer;
};

#endif
