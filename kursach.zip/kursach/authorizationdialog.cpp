#include "authorizationdialog.h"
#include "ui_authorizationdialog.h"

AuthorizationDialog::AuthorizationDialog(QTableWidget *tableWidget, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AuthorizationDialog),
    tableWidget(tableWidget)
{
    ui->setupUi(this);

    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("C:/QT PROJECTS/kursach/mydatabase.db");
    if (!db.open()) {
        QMessageBox::critical(this, "Ошибка", "Ошибка открытия базы данных: " + db.lastError().text());
    }

    connect(ui->loginButton, &QPushButton::clicked, this, &AuthorizationDialog::on_buttonBox_accepted);

}


AuthorizationDialog::~AuthorizationDialog()
{
    delete ui;
}

void AuthorizationDialog::on_buttonBox_accepted()
{
    QString login = ui->loginLineEdit->text();
    QString password = ui->passwordLineEdit->text();

    QSqlQuery query(db);
    query.prepare("SELECT * FROM users WHERE login = :login AND password = :password");
    query.bindValue(":login", login);
    query.bindValue(":password", password);
    if (!query.exec()) {
        QMessageBox::critical(this, "Ошибка", "Ошибка выполнения запроса: " + query.lastError().text());
    } else {
        if (query.next()) {
            this->login = login;
            if (login == "admin") {
                // Пользователь является администратором
                // Разрешить редактирование данных
                tableWidget->setEditTriggers(QAbstractItemView::DoubleClicked | QAbstractItemView::SelectedClicked);
            } else {
                // Пользователь не является администратором
                // Запретить редактирование данных
                tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
            }
            accept();
        } else {
            QMessageBox::warning(this, "Ошибка", "Неверный логин или пароль");
        }
    }
}

QString AuthorizationDialog::getLogin() const
{
    return login;
}


