#include "mainwindowusers.h"
#include "ui_mainwindowusers.h"
#include "mainwindow.h"
#include <QSqlRecord>

MainWindowUsers::MainWindowUsers(MainWindow *mainWindow, QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindowUsers),
    mainWindow(mainWindow)
{
    ui->setupUi(this);

    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("C:/QT PROJECTS/kursach/mydatabase.db");
    if (!db.open()) {
        QMessageBox::critical(this, "Ошибка", "Ошибка открытия базы данных: " + db.lastError().text());
    }

    showUsers();

    connect(ui->lineEdit, &QLineEdit::textChanged, this, &MainWindowUsers::searchUsers);

    QHeaderView *header = ui->tableWidget->horizontalHeader();
    header->setSortIndicatorShown(true);
    header->setSectionsClickable(true);
    connect(header, &QHeaderView::sectionClicked, this, &MainWindowUsers::headerClicked);
}

MainWindowUsers::~MainWindowUsers()
{
    delete ui;
}

void MainWindowUsers::showUsers()
{
    QSqlQuery query(db);
    query.prepare("SELECT * FROM readers");
    if (!query.exec()) {
        QMessageBox::critical(this, "Ошибка", "Ошибка выполнения запроса: " + query.lastError().text());
    } else {
        ui->tableWidget->setRowCount(0);
        ui->tableWidget->setColumnCount(query.record().count());
        ui->tableWidget->setHorizontalHeaderLabels(QStringList() << "ID" << "Имя" << "Контактная информация");
        ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
        while (query.next()) {
            ui->tableWidget->insertRow(ui->tableWidget->rowCount());
            for (int col = 0; col < query.record().count(); ++col) {
                QTableWidgetItem *item = new QTableWidgetItem(query.value(col).toString());
                ui->tableWidget->setItem(ui->tableWidget->rowCount() - 1, col, item);
            }
        }
        ui->tableWidget->update();
    }
}

void MainWindowUsers::searchUsers(const QString &text)
{
    if (text.length() < 2) {
        showUsers();
        return;
    }

    QSqlQuery query(db);
    query.prepare("SELECT * FROM readers WHERE lower(Имя) LIKE lower(:text) OR lower(Контактная_информация) LIKE lower(:text)");
    query.bindValue(":text", "%" + text + "%");
    if (!query.exec()) {
        QMessageBox::critical(this, "Ошибка", "Ошибка выполнения запроса: " + query.lastError().text());
    } else {
        ui->tableWidget->setRowCount(0);
        while (query.next()) {
            ui->tableWidget->insertRow(ui->tableWidget->rowCount());
            for (int col = 0; col < query.record().count(); ++col) {
                QTableWidgetItem *item = new QTableWidgetItem(query.value(col).toString());
                ui->tableWidget->setItem(ui->tableWidget->rowCount() - 1, col, item);
            }
        }
        ui->tableWidget->update();
    }
}

void MainWindowUsers::headerClicked(int column)
{
    static bool ascending = true;
    ui->tableWidget->sortByColumn(column, ascending ? Qt::AscendingOrder : Qt::DescendingOrder);
    ascending = !ascending;
}

void MainWindowUsers::on_pushButton_clicked()
{
    mainWindow->show();
    this->hide();
}

void MainWindowUsers::on_tableWidget_itemChanged(QTableWidgetItem *item)
{
    int column = item->column();
    int row = item->row();

    QString field;
    switch (column) {
        case 0: field = "ID_читателя"; break;
        case 1: field = "Имя"; break;
        case 2: field = "Контактная_информация"; break;
        default: return;
    }

    QString id = ui->tableWidget->item(row, 0)->text();
    QString value = item->text();

    QSqlQuery query(db);
    query.prepare(QString("UPDATE readers SET %1 = :value WHERE ID_читателя = :id").arg(field));
    query.bindValue(":value", value);
    query.bindValue(":id", id);
    if (!query.exec()) {
        QMessageBox::critical(this, "Ошибка", "Ошибка выполнения запроса: " + query.lastError().text());
    }
}
