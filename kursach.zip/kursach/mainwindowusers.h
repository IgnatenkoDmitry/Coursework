#ifndef MAINWINDOWUSERS_H
#define MAINWINDOWUSERS_H

#include <QMainWindow>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QTableWidgetItem>

class MainWindow;

namespace Ui {
class MainWindowUsers;
}

class MainWindowUsers : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindowUsers(MainWindow *mainWindow, QWidget *parent = nullptr);
    ~MainWindowUsers();

private slots:
    void searchUsers(const QString &text);
    void on_tableWidget_itemChanged(QTableWidgetItem *item);
    void on_pushButton_clicked();

private:
    void showUsers();
    void headerClicked(int column);

    Ui::MainWindowUsers *ui;
    QSqlDatabase db;
    QString login;
    MainWindow *mainWindow;
};

#endif
