#ifndef AUTHORIZATIONDIALOG_H
#define AUTHORIZATIONDIALOG_H

#include <QDialog>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QTableWidget>
#include <QtTest>


namespace Ui {
class AuthorizationDialog;
}

class AuthorizationDialog : public QDialog
{
    Q_OBJECT

public:
    explicit AuthorizationDialog(QTableWidget *tableWidget, QWidget *parent = nullptr);
    ~AuthorizationDialog();

    QString getLogin() const;

private slots:
    void on_buttonBox_accepted();

private:
    Ui::AuthorizationDialog *ui;
    QSqlDatabase db;
    QTableWidget *tableWidget;
    QString login;
};

#endif // AUTHORIZATIONDIALOG_H
