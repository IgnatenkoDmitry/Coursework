#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QTableWidgetItem>
#include "orderwindow.h"

class MainWindowUsers;

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    friend class MainWindowUsers;

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void capitalizeText(const QString &text);
    QTableWidget* getTableWidget();
    void searchBooks(const QString &text);
    void filterBooksByCategory(const QString &category);
    void on_tableWidget_itemChanged(QTableWidgetItem *item);
    void on_pushButton_clicked();
    void on_orderButton_clicked();

private:
    void showBooks();
    void headerClicked(int column);
    int getCurrentUserId();

    Ui::MainWindow *ui;
    QSqlDatabase db;
    QString login;
};

#endif
