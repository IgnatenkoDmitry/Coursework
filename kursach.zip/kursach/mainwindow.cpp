    #include "mainwindow.h"
    #include "ui_mainwindow.h"
    #include "authorizationdialog.h"
    #include "mainwindowusers.h"
    #include <QSqlRecord>

    MainWindow::MainWindow(QWidget *parent) :
        QMainWindow(parent),
        ui(new Ui::MainWindow)
    {
        ui->setupUi(this);

        db = QSqlDatabase::addDatabase("QSQLITE");
        db.setDatabaseName("C:/QT PROJECTS/kursach/mydatabase.db");
        if (!db.open()) {
            QMessageBox::critical(this, "Ошибка", "Ошибка открытия базы данных: " + db.lastError().text());
        }

        AuthorizationDialog authDialog(ui->tableWidget, this);
        if (authDialog.exec() == QDialog::Accepted) {
            login = authDialog.getLogin();
            if (login == "admin") {
                // Пользователь является администратором
                // Разрешить редактирование данных
                ui->pushButton->setVisible(true); // Показать кнопку
                ui->tableWidget->setEditTriggers(QAbstractItemView::DoubleClicked | QAbstractItemView::SelectedClicked);
                ui->orderButton->setVisible(false); // Скрываем кнопку
            } else {
                // Пользователь не является администратором
                // Запретить редактирование данных
                ui->pushButton->setVisible(false); // Скрыть кнопку
                ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
                ui->orderButton->setVisible(true); // Показываем кнопку
            }
        } else {
            exit(0);
        }

        showBooks();

        connect(ui->lineEdit, &QLineEdit::textChanged, this, &MainWindow::searchBooks);
        connect(ui->comboBox, &QComboBox::currentTextChanged, this, &MainWindow::filterBooksByCategory);

        ui->comboBox->addItem("Выбор категории");

        QSqlQuery query(db);
        query.prepare("SELECT Название_категории FROM category");
        if (!query.exec()) {
            QMessageBox::critical(this, "Ошибка", "Ошибка выполнения запроса: " + query.lastError().text());
        } else {
            while (query.next()) {
                ui->comboBox->addItem(query.value(0).toString());
            }
        }


        QHeaderView *header = ui->tableWidget->horizontalHeader();
        header->setSortIndicatorShown(true);
        header->setSectionsClickable(true);
        connect(header, &QHeaderView::sectionClicked, this, &MainWindow::headerClicked);
    }

    MainWindow::~MainWindow()
    {
        delete ui;
    }

    void MainWindow::showBooks()
    {
        QSqlQuery query(db);
        query.prepare("SELECT books.ID_книги, books.Название, books.Год, books.Количество_страниц, category.Название_категории, authors.Имя_автора FROM books INNER JOIN category ON books.ID_категории = category.ID_категории INNER JOIN authors ON books.ID_автора = authors.ID_автора");
        if (!query.exec()) {
            QMessageBox::critical(this, "Ошибка", "Ошибка выполнения запроса: " + query.lastError().text());
        } else {
            ui->tableWidget->setRowCount(0);
            ui->tableWidget->setColumnCount(query.record().count());
            ui->tableWidget->setHorizontalHeaderLabels(QStringList() << "Номер" << "Название" << "Год" << "Кол-во страниц" << "Категория" << "Автор");
            ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
            while (query.next()) {
                ui->tableWidget->insertRow(ui->tableWidget->rowCount());
                for (int col = 0; col < query.record().count(); ++col) {
                    QTableWidgetItem *item = new QTableWidgetItem(query.value(col).toString());
                    ui->tableWidget->setItem(ui->tableWidget->rowCount() - 1, col, item);
                }
            }
            ui->tableWidget->update();
        }
    }

    void MainWindow::searchBooks(const QString &text)
    {
        if (text.length() < 2) {
            showBooks();
            return;
        }

        QSqlQuery query(db);
        query.prepare("SELECT books.ID_книги, books.Название, books.Год, books.Количество_страниц, category.Название_категории, authors.Имя_автора FROM books INNER JOIN category ON books.ID_категории = category.ID_категории INNER JOIN authors ON books.ID_автора = authors.ID_автора WHERE lower(books.Название) LIKE lower(:text) OR lower(authors.Имя_автора) LIKE lower(:text)");
        query.bindValue(":text", "%" + text + "%");
        if (!query.exec()) {
            QMessageBox::critical(this, "Ошибка", "Ошибка выполнения запроса: " + query.lastError().text());
        } else {
            ui->tableWidget->setRowCount(0); // Устанавливаем количество строк в 0
            while (query.next()) {
                ui->tableWidget->insertRow(ui->tableWidget->rowCount());
                for (int col = 0; col < query.record().count(); ++col) {
                    QTableWidgetItem *item = new QTableWidgetItem(query.value(col).toString());
                    ui->tableWidget->setItem(ui->tableWidget->rowCount() - 1, col, item);
                }
            }
            ui->tableWidget->update();
        }
    }

    void MainWindow::filterBooksByCategory(const QString &category)
    {

        if (category == "Выбор категории") {
            showBooks();
            return;
        }

        QSqlQuery query(db);
        query.prepare("SELECT books.ID_книги, books.Название, books.Год, books.Количество_страниц, category.Название_категории, authors.Имя_автора FROM books INNER JOIN category ON books.ID_категории = category.ID_категории INNER JOIN authors ON books.ID_автора = authors.ID_автора WHERE category.Название_категории = :category");
        query.bindValue(":category", category);
        if (!query.exec()) {
            QMessageBox::critical(this, "Ошибка", "Ошибка выполнения запроса: " + query.lastError().text());
        } else {
            ui->tableWidget->setRowCount(0);
            while (query.next()) {
                ui->tableWidget->insertRow(ui->tableWidget->rowCount());
                for (int col = 0; col < query.record().count(); ++col) {
                    QTableWidgetItem *item = new QTableWidgetItem(query.value(col).toString());
                    ui->tableWidget->setItem(ui->tableWidget->rowCount() - 1, col, item);
                }
            }
            ui->tableWidget->update();
        }
    }

    void MainWindow::headerClicked(int column)
    {
        static bool ascending = true;
        ui->tableWidget->sortByColumn(column, ascending ? Qt::AscendingOrder : Qt::DescendingOrder);
        ascending = !ascending;
    }



    void MainWindow::capitalizeText(const QString &text)
    {
        if (text.isEmpty()) {
            return;
        }

        QString capitalizedText = text;
        capitalizedText[0] = capitalizedText[0].toUpper();

        if (capitalizedText != text) {
            ui->lineEdit->blockSignals(true);
            ui->lineEdit->setText(capitalizedText);
            ui->lineEdit->blockSignals(false);
        }
    }

    QTableWidget* MainWindow::getTableWidget()
    {
        return ui->tableWidget;
    }

    void MainWindow::on_pushButton_clicked()
    {
        MainWindowUsers *windowUsers = new MainWindowUsers(this);
        windowUsers->show();
        this->hide();

    }

    void MainWindow::on_tableWidget_itemChanged(QTableWidgetItem *item)
    {
        int column = item->column();
        int row = item->row();

        QString field;
        switch (column) {
            case 0: field = "ID_книги"; break;
            case 1: field = "Название"; break;
            case 2: field = "Год"; break;
            case 3: field = "Количество_страниц"; break;
            default: return;
        }

        QString id = ui->tableWidget->item(row, 0)->text();
        QString value = item->text();

        QSqlQuery query(db);
        query.prepare(QString("UPDATE books SET %1 = :value WHERE ID_книги = :id").arg(field));
        query.bindValue(":value", value);
        query.bindValue(":id", id);
        if (!query.exec()) {
            QMessageBox::critical(this, "Ошибка", "Ошибка выполнения запроса: " + query.lastError().text());
        }
    }

    void MainWindow::on_orderButton_clicked()
    {
        int readerId = getCurrentUserId();
        OrderWindow *orderWindow = new OrderWindow(readerId, this);
        orderWindow->show();
    }
    int MainWindow::getCurrentUserId()
    {
        return 0;
    }
